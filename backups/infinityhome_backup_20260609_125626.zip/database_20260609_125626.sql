-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: adexpert_recouvrement_db
-- ------------------------------------------------------
-- Server version	11.7.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_app_user`
--

DROP TABLE IF EXISTS `auth_app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_app_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `role` varchar(20) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `locataire_profile_id` bigint(20) DEFAULT NULL,
  `proprietaire_profile_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `locataire_profile_id` (`locataire_profile_id`),
  UNIQUE KEY `proprietaire_profile_id` (`proprietaire_profile_id`),
  CONSTRAINT `auth_app_user_locataire_profile_id_6bbe96aa_fk_locataire` FOREIGN KEY (`locataire_profile_id`) REFERENCES `locataires_locataire` (`id`),
  CONSTRAINT `auth_app_user_proprietaire_profile_01b059e1_fk_proprieta` FOREIGN KEY (`proprietaire_profile_id`) REFERENCES `proprietaires_proprietaire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_app_user`
--

LOCK TABLES `auth_app_user` WRITE;
/*!40000 ALTER TABLE `auth_app_user` DISABLE KEYS */;
INSERT INTO `auth_app_user` VALUES (1,'pbkdf2_sha256$600000$ORTYYp5g08q1VIraIzRQFK$HPVbl4MTCVSseAOgfegeMaWsCSKBHGQCE+/m7k+uPQ8=','2026-05-09 19:18:31.164631',1,'admin','Admin','Systeme','admin@infinityhome.bi',1,1,'2026-05-09 19:06:25.630498','admin','',NULL,NULL),(2,'pbkdf2_sha256$600000$9gHf7Zw7rMPFExsUxw3SWX$ccCU5KpqlrYtG17n6phDReXnkeIX8pKIi6MtYPH1h3M=',NULL,0,'gestionnaire1','Marie','HAKIZIMANA','gest@infinityhome.bi',0,1,'2026-05-09 19:06:26.634197','gestionnaire','',NULL,NULL),(3,'pbkdf2_sha256$600000$4l34jdZdOHREPLqcIOwUaB$DclRoTHadWSm/Bd1h5mrIlrCh23PbCeMYWJPc2lG8bQ=',NULL,0,'proprietaire1','Jean Pierre','NKURUNZIZA','prop@email.com',0,1,'2026-05-09 19:06:27.571041','proprietaire','',NULL,1),(4,'pbkdf2_sha256$600000$5kDqimskg5tRjz5Q05M4V2$JBn30O5jmYqU9AGTEFKgZHBPNLNJlGdZh9IfmevDxI4=',NULL,0,'locataire1','Patrick','HABIMANA','patrick@email.com',0,1,'2026-05-09 19:06:28.703783','locataire','',1,NULL),(5,'pbkdf2_sha256$600000$bdoWVlYBidY0TYxXQHRIKc$gLJkIi0lC3Hk2WojXWo8VnhLx7GGB+rHgnfd8XQ6rN4=',NULL,0,'supportADE','','','support@ade.bi',1,1,'2026-05-09 19:16:05.219811','lecteur','',NULL,NULL),(6,'pbkdf2_sha256$600000$S8GM26VhsmrMzmSQ4TWfPO$//UkiQDQKLyxb4OniyB2ghLi1onRtBROAaq4ScILQk0=',NULL,0,'Willy','Willy','Kabura','nyamitw@gmail.com',0,1,'2026-05-10 14:54:51.389666','lecteur','67000988',NULL,NULL),(7,'pbkdf2_sha256$600000$B7AZmdqFHuPaj4bToF0NNp$uzUa+ljbyijQ3jW35OX6+RQ7XPJ0lFFxK7W0iHkisyw=',NULL,0,'kabura','Gerard','Kabura','kabura@gmail.com',0,1,'2026-05-10 14:56:26.359235','gestionnaire','',NULL,NULL),(8,'pbkdf2_sha256$600000$7tWt16qSeBuStHlNRtjqIn$T5WqEerWg+OwSACrrp8iMFAD6DRHj/iuIYl8pLnt7tM=',NULL,0,'diella','Diella','keza','',0,1,'2026-05-10 15:17:51.833868','gestionnaire','',NULL,NULL),(9,'pbkdf2_sha256$600000$WH7dvoSdweCajVpzxVppxj$zNLzgXaHbtR9qejeeneuuKwbB77q67s7UO/1tGZ+kxY=',NULL,0,'MarcIIII','Keza','Jeanine','',0,1,'2026-05-14 15:11:05.635480','locataire','',2,NULL),(10,'pbkdf2_sha256$600000$tZ0Ej2IBuFu9778G2wliGG$b695eCwVKTwMx2COZhUbmRa06HcFp6XO12zPBE0Slws=',NULL,0,'JohnKarikurubu','John','Karikurubu','',0,1,'2026-05-26 08:10:01.570662','lecteur','',NULL,NULL),(11,'pbkdf2_sha256$600000$OD35Yxrfl21kGJo7l7sGZL$icS1BChwfgmuOoJhNFPp9RA/T6YsNXuzLl8JLQS8LKs=',NULL,0,'niyuru','Willy','Niyuru','w@gmail.com',0,1,'2026-05-26 08:21:14.212449','proprietaire','',NULL,2),(12,'pbkdf2_sha256$600000$NIZ604ZGiAkj6HOVyFE73G$ijM6So6rR3zHu9RKh75b1rYwFPWlawT8wbaH0IsBfvE=',NULL,0,'Wallace','Wallace','Rukundo','walla@gmail.com',0,1,'2026-05-28 09:30:37.334353','lecteur','',NULL,NULL),(14,'pbkdf2_sha256$600000$LqPEGb9LzZYG5FcnQdjqAd$J/64KXYDsJ9PIjBWg/ehyYDITugDRgR1Ww9p7yQfWFU=',NULL,0,'hilaire','Hilaire','Ngenzebuhoro','hilaire@gmail.com',0,1,'2026-06-03 10:26:36.177464','locataire','',5,4);
/*!40000 ALTER TABLE `auth_app_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_app_user_groups`
--

DROP TABLE IF EXISTS `auth_app_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_app_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_app_user_groups_user_id_group_id_5f174ff0_uniq` (`user_id`,`group_id`),
  KEY `auth_app_user_groups_group_id_b4576925_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_app_user_groups_group_id_b4576925_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_app_user_groups_user_id_2b6e45f5_fk_auth_app_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_app_user_groups`
--

LOCK TABLES `auth_app_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_app_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_app_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_app_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_app_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_app_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_app_user_user_permi_user_id_permission_id_727a8e97_uniq` (`user_id`,`permission_id`),
  KEY `auth_app_user_user_p_permission_id_cc1b2396_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_app_user_user_p_permission_id_cc1b2396_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_app_user_user_p_user_id_b7c37328_fk_auth_app_` FOREIGN KEY (`user_id`) REFERENCES `auth_app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_app_user_user_permissions`
--

LOCK TABLES `auth_app_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_app_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_app_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can view permission',1,'view_permission'),(5,'Can add group',2,'add_group'),(6,'Can change group',2,'change_group'),(7,'Can delete group',2,'delete_group'),(8,'Can view group',2,'view_group'),(9,'Can add content type',3,'add_contenttype'),(10,'Can change content type',3,'change_contenttype'),(11,'Can delete content type',3,'delete_contenttype'),(12,'Can view content type',3,'view_contenttype'),(13,'Can add Utilisateur',4,'add_user'),(14,'Can change Utilisateur',4,'change_user'),(15,'Can delete Utilisateur',4,'delete_user'),(16,'Can view Utilisateur',4,'view_user'),(17,'Can add Propriétaire',5,'add_proprietaire'),(18,'Can change Propriétaire',5,'change_proprietaire'),(19,'Can delete Propriétaire',5,'delete_proprietaire'),(20,'Can view Propriétaire',5,'view_proprietaire'),(21,'Can add Locataire',6,'add_locataire'),(22,'Can change Locataire',6,'change_locataire'),(23,'Can delete Locataire',6,'delete_locataire'),(24,'Can view Locataire',6,'view_locataire'),(25,'Can add log entry',7,'add_logentry'),(26,'Can change log entry',7,'change_logentry'),(27,'Can delete log entry',7,'delete_logentry'),(28,'Can view log entry',7,'view_logentry'),(29,'Can add session',8,'add_session'),(30,'Can change session',8,'change_session'),(31,'Can delete session',8,'delete_session'),(32,'Can view session',8,'view_session'),(33,'Can add Token',9,'add_token'),(34,'Can change Token',9,'change_token'),(35,'Can delete Token',9,'delete_token'),(36,'Can view Token',9,'view_token'),(37,'Can add token',10,'add_tokenproxy'),(38,'Can change token',10,'change_tokenproxy'),(39,'Can delete token',10,'delete_tokenproxy'),(40,'Can view token',10,'view_tokenproxy'),(41,'Can add Immeuble',11,'add_immeuble'),(42,'Can change Immeuble',11,'change_immeuble'),(43,'Can delete Immeuble',11,'delete_immeuble'),(44,'Can view Immeuble',11,'view_immeuble'),(45,'Can add Local',12,'add_local'),(46,'Can change Local',12,'change_local'),(47,'Can delete Local',12,'delete_local'),(48,'Can view Local',12,'view_local'),(49,'Can add Contrat Société',13,'add_contratsociete'),(50,'Can change Contrat Société',13,'change_contratsociete'),(51,'Can delete Contrat Société',13,'delete_contratsociete'),(52,'Can view Contrat Société',13,'view_contratsociete'),(53,'Can add Contrat',14,'add_contrat'),(54,'Can change Contrat',14,'change_contrat'),(55,'Can delete Contrat',14,'delete_contrat'),(56,'Can view Contrat',14,'view_contrat'),(57,'Can add Loyer',15,'add_loyer'),(58,'Can change Loyer',15,'change_loyer'),(59,'Can delete Loyer',15,'delete_loyer'),(60,'Can view Loyer',15,'view_loyer'),(61,'Can add paiement',16,'add_paiement'),(62,'Can change paiement',16,'change_paiement'),(63,'Can delete paiement',16,'delete_paiement'),(64,'Can view paiement',16,'view_paiement'),(65,'Can add Bordereau',17,'add_bordereau'),(66,'Can change Bordereau',17,'change_bordereau'),(67,'Can delete Bordereau',17,'delete_bordereau'),(68,'Can view Bordereau',17,'view_bordereau'),(69,'Can add charge',18,'add_charge'),(70,'Can change charge',18,'change_charge'),(71,'Can delete charge',18,'delete_charge'),(72,'Can view charge',18,'view_charge'),(73,'Can add group chat',19,'add_groupchat'),(74,'Can change group chat',19,'change_groupchat'),(75,'Can delete group chat',19,'delete_groupchat'),(76,'Can view group chat',19,'view_groupchat'),(77,'Can add group message',20,'add_groupmessage'),(78,'Can change group message',20,'change_groupmessage'),(79,'Can delete group message',20,'delete_groupmessage'),(80,'Can view group message',20,'view_groupmessage'),(81,'Can add Notification',21,'add_notification'),(82,'Can change Notification',21,'change_notification'),(83,'Can delete Notification',21,'delete_notification'),(84,'Can view Notification',21,'view_notification');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authtoken_token`
--

DROP TABLE IF EXISTS `authtoken_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `authtoken_token` (
  `key` varchar(40) NOT NULL,
  `created` datetime(6) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`key`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `authtoken_token_user_id_35299eff_fk_auth_app_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authtoken_token`
--

LOCK TABLES `authtoken_token` WRITE;
/*!40000 ALTER TABLE `authtoken_token` DISABLE KEYS */;
INSERT INTO `authtoken_token` VALUES ('84371073928adcc92748c2d380e989c0a99e8558','2026-06-09 09:49:54.213012',1),('d18b5f41d5baa23b672c4c7dcc581f731f253521','2026-06-09 08:24:02.773849',2);
/*!40000 ALTER TABLE `authtoken_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `charges_charge`
--

DROP TABLE IF EXISTS `charges_charge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `charges_charge` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `type_charge` varchar(30) NOT NULL,
  `montant_ttc` decimal(12,2) NOT NULL,
  `date_charge` date NOT NULL,
  `notes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `immeuble_id` bigint(20) DEFAULT NULL,
  `local_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `charges_charge_immeuble_id_d08ad9fa_fk_immeubles_immeuble_id` (`immeuble_id`),
  KEY `charges_charge_local_id_2300d9db_fk_locaux_local_id` (`local_id`),
  CONSTRAINT `charges_charge_immeuble_id_d08ad9fa_fk_immeubles_immeuble_id` FOREIGN KEY (`immeuble_id`) REFERENCES `immeubles_immeuble` (`id`),
  CONSTRAINT `charges_charge_local_id_2300d9db_fk_locaux_local_id` FOREIGN KEY (`local_id`) REFERENCES `locaux_local` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `charges_charge`
--

LOCK TABLES `charges_charge` WRITE;
/*!40000 ALTER TABLE `charges_charge` DISABLE KEYS */;
INSERT INTO `charges_charge` VALUES (1,'traveaux entretien','travaux',450000.00,'2026-05-10','','2026-05-10 14:17:35.704280',1,1),(2,'L00099','impot_foncier',6000000.00,'2026-05-14','','2026-05-14 14:15:30.956500',2,1),(3,'L00099','impot_foncier',6000000.00,'2026-05-14','','2026-05-14 14:15:33.282596',2,1),(4,'L00099','impot_foncier',6000000.00,'2026-05-14','','2026-05-14 14:15:33.722120',2,1),(5,'L00099','impot_foncier',6000000.00,'2026-05-14','','2026-05-14 14:15:34.346381',2,1);
/*!40000 ALTER TABLE `charges_charge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_groupchat`
--

DROP TABLE IF EXISTS `chat_groupchat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_groupchat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `immeuble_id` bigint(20) NOT NULL,
  `proprietaire_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `immeuble_id` (`immeuble_id`),
  KEY `chat_groupchat_proprietaire_id_2d7dba35_fk_proprieta` (`proprietaire_id`),
  CONSTRAINT `chat_groupchat_immeuble_id_e831694e_fk_immeubles_immeuble_id` FOREIGN KEY (`immeuble_id`) REFERENCES `immeubles_immeuble` (`id`),
  CONSTRAINT `chat_groupchat_proprietaire_id_2d7dba35_fk_proprieta` FOREIGN KEY (`proprietaire_id`) REFERENCES `proprietaires_proprietaire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_groupchat`
--

LOCK TABLES `chat_groupchat` WRITE;
/*!40000 ALTER TABLE `chat_groupchat` DISABLE KEYS */;
INSERT INTO `chat_groupchat` VALUES (1,'Chat — Immeuble Rohero Center','2026-05-09 19:06:28.519848',1,1),(2,'Chat — Immeuble','2026-05-26 12:07:07.214483',2,1),(4,'Chat — Ndamama House','2026-06-03 10:24:51.617772',5,4),(5,'Chat — Ndongozi','2026-06-08 07:18:17.025940',3,1);
/*!40000 ALTER TABLE `chat_groupchat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_groupmessage`
--

DROP TABLE IF EXISTS `chat_groupmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_groupmessage` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contenu` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `auteur_id` bigint(20) DEFAULT NULL,
  `group_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `chat_groupmessage_auteur_id_6c435380_fk_auth_app_user_id` (`auteur_id`),
  KEY `chat_groupmessage_group_id_754429fc_fk_chat_groupchat_id` (`group_id`),
  CONSTRAINT `chat_groupmessage_auteur_id_6c435380_fk_auth_app_user_id` FOREIGN KEY (`auteur_id`) REFERENCES `auth_app_user` (`id`),
  CONSTRAINT `chat_groupmessage_group_id_754429fc_fk_chat_groupchat_id` FOREIGN KEY (`group_id`) REFERENCES `chat_groupchat` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_groupmessage`
--

LOCK TABLES `chat_groupmessage` WRITE;
/*!40000 ALTER TABLE `chat_groupmessage` DISABLE KEYS */;
INSERT INTO `chat_groupmessage` VALUES (1,'hhhhh','2026-05-26 11:59:55.044442',4,1),(2,'Bonjour','2026-05-26 12:00:40.454735',2,1),(3,'Hello','2026-05-26 12:07:37.248418',2,2),(5,'hh','2026-05-28 08:51:44.876273',4,1),(6,'^Saluuuuut','2026-05-29 12:31:49.988512',4,1),(7,'saluuuuuuuuuuuuuu','2026-05-30 06:42:56.349816',11,1),(9,'helooooooooooooo','2026-05-30 19:20:08.726240',4,1),(11,'hi','2026-06-03 10:25:00.486866',1,4),(12,'sqlu','2026-06-04 11:32:24.013756',3,1),(13,'hello','2026-06-04 12:09:21.658060',4,1),(14,'hi','2026-06-09 09:43:49.901522',2,4);
/*!40000 ALTER TABLE `chat_groupmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contrats_contrat`
--

DROP TABLE IF EXISTS `contrats_contrat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contrats_contrat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `numero` varchar(50) NOT NULL,
  `statut` varchar(20) NOT NULL,
  `loyer_hors_charges` decimal(12,2) NOT NULL,
  `provisions_charges` decimal(12,2) NOT NULL,
  `periodicite` varchar(20) NOT NULL,
  `depot_garantie` decimal(12,2) NOT NULL,
  `date_entree` date NOT NULL,
  `date_sortie` date DEFAULT NULL,
  `informations_complementaires` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `local_id` bigint(20) NOT NULL,
  `locataire_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero` (`numero`),
  KEY `contrats_contrat_local_id_12e3c315_fk_locaux_local_id` (`local_id`),
  KEY `contrats_contrat_locataire_id_715d7cc6_fk_locataire` (`locataire_id`),
  CONSTRAINT `contrats_contrat_local_id_12e3c315_fk_locaux_local_id` FOREIGN KEY (`local_id`) REFERENCES `locaux_local` (`id`),
  CONSTRAINT `contrats_contrat_locataire_id_715d7cc6_fk_locataire` FOREIGN KEY (`locataire_id`) REFERENCES `locataires_locataire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrats_contrat`
--

LOCK TABLES `contrats_contrat` WRITE;
/*!40000 ALTER TABLE `contrats_contrat` DISABLE KEYS */;
INSERT INTO `contrats_contrat` VALUES (1,'C-2026-001','actif',300000.00,25000.00,'mensuel',600000.00,'2026-01-01',NULL,'','2026-05-09 19:06:29.890851',1,1),(2,'c-2026-002','actif',350000.00,0.00,'mensuel',0.00,'2026-05-10',NULL,'','2026-05-10 19:02:44.857223',1,2),(3,'C-2026-05-12','actif',400000.00,0.00,'mensuel',0.00,'2026-05-12',NULL,'','2026-05-12 15:33:11.093074',3,3),(4,'C-Ndamma-2026','actif',300000.00,0.00,'mensuel',0.00,'2026-06-03',NULL,'','2026-06-03 10:24:31.033859',5,4),(5,'c-5-2026','expire',300000.00,0.00,'mensuel',0.00,'2026-06-04','2027-06-04','','2026-06-04 11:37:33.159164',5,5);
/*!40000 ALTER TABLE `contrats_contrat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contrats_contratsociete`
--

DROP TABLE IF EXISTS `contrats_contratsociete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contrats_contratsociete` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `numero` varchar(50) NOT NULL,
  `date_signature` date NOT NULL,
  `date_effet` date NOT NULL,
  `date_expiration` date DEFAULT NULL,
  `statut` varchar(20) NOT NULL,
  `taux_commission` decimal(5,2) NOT NULL,
  `periodicite_reversement` varchar(20) NOT NULL,
  `frais_entree` decimal(12,2) NOT NULL,
  `service_gestion_loyers` tinyint(1) NOT NULL,
  `service_quittances` tinyint(1) NOT NULL,
  `service_recherche_locataires` tinyint(1) NOT NULL,
  `service_gestion_travaux` tinyint(1) NOT NULL,
  `service_suivi_fiscal` tinyint(1) NOT NULL,
  `service_rapports` tinyint(1) NOT NULL,
  `service_loyers_impayes` tinyint(1) NOT NULL,
  `service_assurances` tinyint(1) NOT NULL,
  `service_judiciaire` tinyint(1) NOT NULL,
  `service_impots_locatifs` tinyint(1) NOT NULL,
  `service_clients` tinyint(1) NOT NULL,
  `service_touristique` tinyint(1) NOT NULL,
  `clauses_particulieres` longtext NOT NULL,
  `notes_internes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `proprietaire_id` bigint(20) NOT NULL,
  `constat_lieu` tinyint(1) NOT NULL,
  `inventaire_immeuble` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `numero` (`numero`),
  KEY `contrats_contratsoci_proprietaire_id_3dbb5fc2_fk_proprieta` (`proprietaire_id`),
  CONSTRAINT `contrats_contratsoci_proprietaire_id_3dbb5fc2_fk_proprieta` FOREIGN KEY (`proprietaire_id`) REFERENCES `proprietaires_proprietaire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contrats_contratsociete`
--

LOCK TABLES `contrats_contratsociete` WRITE;
/*!40000 ALTER TABLE `contrats_contratsociete` DISABLE KEYS */;
INSERT INTO `contrats_contratsociete` VALUES (1,'CS-2026-662','2026-05-10','2026-05-10','2026-05-10','actif',3.00,'mensuel',4000000.00,1,1,1,1,1,1,1,1,1,1,1,0,'','','2026-05-10 14:18:45.631186',1,1,1);
/*!40000 ALTER TABLE `contrats_contratsociete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_app_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_app_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (7,'admin','logentry'),(2,'auth','group'),(1,'auth','permission'),(4,'auth_app','user'),(9,'authtoken','token'),(10,'authtoken','tokenproxy'),(18,'charges','charge'),(19,'chat','groupchat'),(20,'chat','groupmessage'),(3,'contenttypes','contenttype'),(14,'contrats','contrat'),(13,'contrats','contratsociete'),(11,'immeubles','immeuble'),(6,'locataires','locataire'),(12,'locaux','local'),(17,'loyers','bordereau'),(15,'loyers','loyer'),(16,'loyers','paiement'),(21,'notifications','notification'),(5,'proprietaires','proprietaire'),(8,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2026-05-09 19:04:53.008505'),(2,'proprietaires','0001_initial','2026-05-09 19:04:53.248321'),(3,'locataires','0001_initial','2026-05-09 19:04:53.417358'),(4,'contenttypes','0002_remove_content_type_name','2026-05-09 19:04:54.121556'),(5,'auth','0001_initial','2026-05-09 19:04:57.093874'),(6,'auth','0002_alter_permission_name_max_length','2026-05-09 19:04:57.657807'),(7,'auth','0003_alter_user_email_max_length','2026-05-09 19:04:57.736016'),(8,'auth','0004_alter_user_username_opts','2026-05-09 19:04:57.768470'),(9,'auth','0005_alter_user_last_login_null','2026-05-09 19:04:57.790737'),(10,'auth','0006_require_contenttypes_0002','2026-05-09 19:04:57.803644'),(11,'auth','0007_alter_validators_add_error_messages','2026-05-09 19:04:57.825124'),(12,'auth','0008_alter_user_username_max_length','2026-05-09 19:04:57.843452'),(13,'auth','0009_alter_user_last_name_max_length','2026-05-09 19:04:57.866821'),(14,'auth','0010_alter_group_name_max_length','2026-05-09 19:04:58.230842'),(15,'auth','0011_update_proxy_permissions','2026-05-09 19:04:58.289415'),(16,'auth','0012_alter_user_first_name_max_length','2026-05-09 19:04:58.331986'),(17,'auth_app','0001_initial','2026-05-09 19:05:03.731710'),(18,'admin','0001_initial','2026-05-09 19:05:35.058327'),(19,'admin','0002_logentry_remove_auto_add','2026-05-09 19:05:35.115063'),(20,'admin','0003_logentry_add_action_flag_choices','2026-05-09 19:05:35.159112'),(21,'authtoken','0001_initial','2026-05-09 19:05:36.032678'),(22,'authtoken','0002_auto_20160226_1747','2026-05-09 19:05:36.110740'),(23,'authtoken','0003_tokenproxy','2026-05-09 19:05:36.134940'),(24,'immeubles','0001_initial','2026-05-09 19:05:36.314464'),(25,'locaux','0001_initial','2026-05-09 19:05:37.843218'),(26,'charges','0001_initial','2026-05-09 19:05:38.978709'),(27,'chat','0001_initial','2026-05-09 19:05:41.314716'),(28,'contrats','0001_initial','2026-05-09 19:05:43.943084'),(29,'loyers','0001_initial','2026-05-09 19:05:48.205756'),(30,'notifications','0001_initial','2026-05-09 19:05:49.655064'),(31,'sessions','0001_initial','2026-05-09 19:05:50.218265'),(32,'locataires','0002_locataire_mot_de_passe_temp','2026-06-01 11:09:11.039441'),(33,'proprietaires','0002_proprietaire_mot_de_passe_temp','2026-06-01 11:09:11.855706'),(34,'immeubles','0002_immeuble_proprietaire','2026-06-03 10:10:02.527962'),(35,'locataires','0003_locataire_user','2026-06-04 14:05:03.872760'),(36,'locataires','0004_remove_locataire_user','2026-06-05 08:53:47.198671'),(37,'contrats','0002_contratsociete_constat_lieu_and_more','2026-06-09 08:47:25.285555');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0y7gf5ive7kpps1a5yjsouiv607pquie','.eJxVjDsOwjAQBe_iGllefxdK-pzBsr0bHECxFCcV4u4QKQW0b2beS8S0rTVunZc4kbgIEKffLafy4HkHdE_zrcnS5nWZstwVedAuh0b8vB7u30FNvX5rVBi8gsRkKDgKYBjAo3YeRsjGKhswFEeAwN5rPGvLI6ICHDMV5cT7A6vxNow:1wLnC3:s5extTXFQgFHfHmaeUiHdp3E2PyzhL1GZIoXIVFj4Lg','2026-05-23 19:18:31.184301');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `immeubles_immeuble`
--

DROP TABLE IF EXISTS `immeubles_immeuble`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `immeubles_immeuble` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `adresse_province` varchar(100) NOT NULL,
  `adresse_commune` varchar(100) NOT NULL,
  `adresse_quartier` varchar(100) NOT NULL,
  `annee_construction` int(11) DEFAULT NULL,
  `informations_complementaires` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `proprietaire_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `immeubles_immeuble_proprietaire_id_f3a805ad_fk_proprieta` (`proprietaire_id`),
  CONSTRAINT `immeubles_immeuble_proprietaire_id_f3a805ad_fk_proprieta` FOREIGN KEY (`proprietaire_id`) REFERENCES `proprietaires_proprietaire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `immeubles_immeuble`
--

LOCK TABLES `immeubles_immeuble` WRITE;
/*!40000 ALTER TABLE `immeubles_immeuble` DISABLE KEYS */;
INSERT INTO `immeubles_immeuble` VALUES (1,'Immeuble Rohero Center','Bujumbura','Mukaza','Rohero',2018,'','2026-05-09 19:06:28.484254',NULL),(2,'Immeuble','Bujumbura','Mukaza','Rohero',2015,'','2026-05-10 18:58:53.185691',NULL),(3,'Ndongozi','Bujumbura','Mukaza','rohero',2017,'','2026-05-11 07:08:17.647555',NULL),(4,'VMarket','Bujumbura','Mukaza','Rohero',NULL,'','2026-05-26 15:32:33.923907',NULL),(5,'Ndamama House','Bujumbura','Mukaza','Rohero',NULL,'','2026-06-03 10:21:58.475615',NULL);
/*!40000 ALTER TABLE `immeubles_immeuble` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locataires_locataire`
--

DROP TABLE IF EXISTS `locataires_locataire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locataires_locataire` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nom_prenom` varchar(200) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `adresse_postale` varchar(300) NOT NULL,
  `informations_complementaires` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `mot_de_passe_temp` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locataires_locataire`
--

LOCK TABLES `locataires_locataire` WRITE;
/*!40000 ALTER TABLE `locataires_locataire` DISABLE KEYS */;
INSERT INTO `locataires_locataire` VALUES (1,'HABIMANA Patrick','+257 79 002 002','patrick@email.com','','','2026-05-09 19:06:28.694935',''),(2,'Gerard','','','','','2026-05-10 19:01:45.108450',''),(3,'Eva Ntibantunganya','','evnet@gmail.com','','','2026-05-12 15:32:07.839771',''),(4,'Nahayo Remy','25775200221','remy@gmail.com','','','2026-06-03 10:23:38.250266',''),(5,'Hilaire Ngenzebuhoro','','','','','2026-06-04 11:35:40.517225','');
/*!40000 ALTER TABLE `locataires_locataire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locaux_local`
--

DROP TABLE IF EXISTS `locaux_local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locaux_local` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) NOT NULL,
  `type_local` varchar(20) NOT NULL,
  `adresse_province` varchar(100) NOT NULL,
  `adresse_commune` varchar(100) NOT NULL,
  `adresse_quartier` varchar(100) NOT NULL,
  `superficie` decimal(8,2) DEFAULT NULL,
  `annee_construction` int(11) DEFAULT NULL,
  `meuble` tinyint(1) NOT NULL,
  `informations_complementaires` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `immeuble_id` bigint(20) DEFAULT NULL,
  `proprietaire_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `locaux_local_immeuble_id_d7d3aa78_fk_immeubles_immeuble_id` (`immeuble_id`),
  KEY `locaux_local_proprietaire_id_fe20c28d_fk_proprieta` (`proprietaire_id`),
  CONSTRAINT `locaux_local_immeuble_id_d7d3aa78_fk_immeubles_immeuble_id` FOREIGN KEY (`immeuble_id`) REFERENCES `immeubles_immeuble` (`id`),
  CONSTRAINT `locaux_local_proprietaire_id_fe20c28d_fk_proprieta` FOREIGN KEY (`proprietaire_id`) REFERENCES `proprietaires_proprietaire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locaux_local`
--

LOCK TABLES `locaux_local` WRITE;
/*!40000 ALTER TABLE `locaux_local` DISABLE KEYS */;
INSERT INTO `locaux_local` VALUES (1,'L-001','appartement','Bujumbura','Mukaza','Rohero',65.00,NULL,1,'','2026-05-09 19:06:28.672589',1,1),(2,'L-002','appartement','Gitega','Mutumba','Musinzira',230.00,NULL,1,'','2026-05-10 19:00:02.951041',2,1),(3,'C4410','bureau','Bujumbura','Ntahangwa','Kigobe Nord',9.00,2018,1,'','2026-05-12 15:30:49.420320',3,1),(5,'Ndamm-L0012','maison','Bujumbura','Mukaza','Rohero',200.00,NULL,1,'','2026-06-03 10:22:58.373815',5,4);
/*!40000 ALTER TABLE `locaux_local` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyers_bordereau`
--

DROP TABLE IF EXISTS `loyers_bordereau`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyers_bordereau` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `photo` varchar(100) NOT NULL,
  `notes` longtext NOT NULL,
  `statut` varchar(20) NOT NULL,
  `commentaire_admin` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `locataire_id` bigint(20) NOT NULL,
  `loyer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `loyers_bordereau_locataire_id_95940405_fk_locataire` (`locataire_id`),
  KEY `loyers_bordereau_loyer_id_902b5764_fk_loyers_loyer_id` (`loyer_id`),
  CONSTRAINT `loyers_bordereau_locataire_id_95940405_fk_locataire` FOREIGN KEY (`locataire_id`) REFERENCES `locataires_locataire` (`id`),
  CONSTRAINT `loyers_bordereau_loyer_id_902b5764_fk_loyers_loyer_id` FOREIGN KEY (`loyer_id`) REFERENCES `loyers_loyer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyers_bordereau`
--

LOCK TABLES `loyers_bordereau` WRITE;
/*!40000 ALTER TABLE `loyers_bordereau` DISABLE KEYS */;
INSERT INTO `loyers_bordereau` VALUES (1,'bordereaux/2026/05/HFX23OGaUAAbqgV.jpg','','valide','','2026-05-10 07:11:31.171566',1,NULL),(13,'bordereaux/2026/05/HGnAZezWUAAqSXK_EO9eg7q.jpg','','valide','','2026-05-11 08:52:44.931631',1,NULL),(24,'bordereaux/2026/05/20260408_231050.jpg','','valide','','2026-05-22 14:08:13.075905',1,NULL),(25,'bordereaux/2026/06/WhatsApp_Image_2026-05-24_at_2.59.04_PM.jpeg','','valide','','2026-06-02 14:30:01.578101',1,NULL),(26,'bordereaux/2026/06/WhatsApp_Image_2026-05-24_at_2.59.04_PM_kiacSTp.jpeg','','valide','','2026-06-02 14:32:06.060019',1,31);
/*!40000 ALTER TABLE `loyers_bordereau` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyers_loyer`
--

DROP TABLE IF EXISTS `loyers_loyer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyers_loyer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  `periode_debut` date NOT NULL,
  `periode_fin` date DEFAULT NULL,
  `loyer_hors_charges` decimal(12,2) NOT NULL,
  `charges` decimal(12,2) NOT NULL,
  `echeance` date NOT NULL,
  `statut` varchar(20) NOT NULL,
  `informations_complementaires` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `contrat_id` bigint(20) DEFAULT NULL,
  `local_id` bigint(20) NOT NULL,
  `locataire_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `loyers_loyer_contrat_id_11197a6d_fk_contrats_contrat_id` (`contrat_id`),
  KEY `loyers_loyer_local_id_40e7d952_fk_locaux_local_id` (`local_id`),
  KEY `loyers_loyer_locataire_id_eed01b7b_fk_locataires_locataire_id` (`locataire_id`),
  CONSTRAINT `loyers_loyer_contrat_id_11197a6d_fk_contrats_contrat_id` FOREIGN KEY (`contrat_id`) REFERENCES `contrats_contrat` (`id`),
  CONSTRAINT `loyers_loyer_local_id_40e7d952_fk_locaux_local_id` FOREIGN KEY (`local_id`) REFERENCES `locaux_local` (`id`),
  CONSTRAINT `loyers_loyer_locataire_id_eed01b7b_fk_locataires_locataire_id` FOREIGN KEY (`locataire_id`) REFERENCES `locataires_locataire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyers_loyer`
--

LOCK TABLES `loyers_loyer` WRITE;
/*!40000 ALTER TABLE `loyers_loyer` DISABLE KEYS */;
INSERT INTO `loyers_loyer` VALUES (30,'Loyer 2026','2026-06-02',NULL,300000.00,0.00,'2026-06-02','paye','','2026-06-02 12:40:59.181979',3,3,1),(31,'Loyer June 2026','2026-06-02','2026-07-01',300000.00,25000.00,'2026-06-02','paye','','2026-06-02 14:30:49.142433',1,1,1),(32,'Loyer July 2026','2026-07-02','2026-08-01',300000.00,25000.00,'2026-07-02','paye','','2026-06-02 14:30:49.231042',1,1,1),(33,'Loyer August 2026','2026-08-02','2026-09-01',300000.00,25000.00,'2026-08-02','paye','','2026-06-02 14:30:49.402121',1,1,1),(34,'Loyer September 2026','2026-09-02','2026-10-01',300000.00,25000.00,'2026-09-02','attente','','2026-06-02 14:30:49.500746',1,1,1),(35,'Loyer October 2026','2026-10-02','2026-11-01',300000.00,25000.00,'2026-10-02','attente','','2026-06-02 14:30:49.572054',1,1,1),(36,'Loyer November 2026','2026-11-02','2026-12-01',300000.00,25000.00,'2026-11-02','attente','','2026-06-02 14:30:49.623781',1,1,1),(37,'Loyer December 2026','2026-12-02','2027-01-01',300000.00,25000.00,'2026-12-02','attente','','2026-06-02 14:30:49.671212',1,1,1),(38,'Loyer January 2027','2027-01-02','2027-02-01',300000.00,25000.00,'2027-01-02','attente','','2026-06-02 14:30:49.729322',1,1,1),(39,'Loyer February 2027','2027-02-02','2027-03-01',300000.00,25000.00,'2027-02-02','paye','','2026-06-02 14:30:49.777238',1,1,1),(40,'Loyer March 2027','2027-03-02','2027-04-01',300000.00,25000.00,'2027-03-02','attente','','2026-06-02 14:30:49.843881',1,1,1),(41,'Loyer April 2027','2027-04-02','2027-05-01',300000.00,25000.00,'2027-04-02','attente','','2026-06-02 14:30:49.910028',1,1,1),(42,'Loyer May 2027','2027-05-02','2027-06-01',300000.00,25000.00,'2027-05-02','attente','','2026-06-02 14:30:49.987277',1,1,1),(43,'Loyer June 2026','2026-06-03','2026-07-02',300000.00,0.00,'2026-06-03','attente','','2026-06-03 14:39:53.669923',4,5,4),(44,'Loyer July 2026','2026-07-03','2026-08-02',300000.00,0.00,'2026-07-03','attente','','2026-06-03 14:39:53.753275',4,5,4),(45,'Loyer August 2026','2026-08-03','2026-09-02',300000.00,0.00,'2026-08-03','attente','','2026-06-03 14:39:53.835085',4,5,4),(46,'Loyer September 2026','2026-09-03','2026-10-02',300000.00,0.00,'2026-09-03','attente','','2026-06-03 14:39:53.877236',4,5,4),(47,'Loyer October 2026','2026-10-03','2026-11-02',300000.00,0.00,'2026-10-03','attente','','2026-06-03 14:39:53.905655',4,5,4),(48,'Loyer November 2026','2026-11-03','2026-12-02',300000.00,0.00,'2026-11-03','attente','','2026-06-03 14:39:53.937981',4,5,4),(49,'Loyer December 2026','2026-12-03','2027-01-02',300000.00,0.00,'2026-12-03','attente','','2026-06-03 14:39:54.009319',4,5,4),(50,'Loyer January 2027','2027-01-03','2027-02-02',300000.00,0.00,'2027-01-03','attente','','2026-06-03 14:39:54.048626',4,5,4),(51,'Loyer February 2027','2027-02-03','2027-03-02',300000.00,0.00,'2027-02-03','attente','','2026-06-03 14:39:54.059727',4,5,4),(52,'Loyer March 2027','2027-03-03','2027-04-02',300000.00,0.00,'2027-03-03','attente','','2026-06-03 14:39:54.070768',4,5,4),(53,'Loyer April 2027','2027-04-03','2027-05-02',300000.00,0.00,'2027-04-03','attente','','2026-06-03 14:39:54.082071',4,5,4),(54,'Loyer May 2027','2027-05-03','2027-06-02',300000.00,0.00,'2027-05-03','attente','','2026-06-03 14:39:54.092947',4,5,4),(55,'Loyer June 2026','2026-06-05','2026-07-04',350000.00,0.00,'2026-06-05','attente','','2026-06-05 12:10:27.715379',2,1,2),(56,'Loyer July 2026','2026-07-05','2026-08-04',350000.00,0.00,'2026-07-05','attente','','2026-06-05 12:10:27.801490',2,1,2),(57,'Loyer August 2026','2026-08-05','2026-09-04',350000.00,0.00,'2026-08-05','attente','','2026-06-05 12:10:27.817344',2,1,2),(58,'Loyer September 2026','2026-09-05','2026-10-04',350000.00,0.00,'2026-09-05','attente','','2026-06-05 12:10:27.827919',2,1,2),(59,'Loyer June 2026','2026-06-08','2026-07-07',300000.00,0.00,'2026-06-08','attente','','2026-06-08 09:52:28.445750',5,5,5),(60,'Loyer July 2026','2026-07-08','2026-08-07',300000.00,0.00,'2026-07-08','attente','','2026-06-08 09:52:28.497962',5,5,5),(61,'Loyer August 2026','2026-08-08','2026-09-07',300000.00,0.00,'2026-08-08','attente','','2026-06-08 09:52:28.513244',5,5,5),(62,'Loyer September 2026','2026-09-08','2026-10-07',300000.00,0.00,'2026-09-08','attente','','2026-06-08 09:52:28.606298',5,5,5),(63,'Loyer October 2026','2026-10-08','2026-11-07',300000.00,0.00,'2026-10-08','attente','','2026-06-08 09:52:28.650491',5,5,5),(64,'Loyer November 2026','2026-11-08','2026-12-07',300000.00,0.00,'2026-11-08','attente','','2026-06-08 09:52:28.780569',5,5,5),(65,'Loyer December 2026','2026-12-08','2027-01-07',300000.00,0.00,'2026-12-08','attente','','2026-06-08 09:52:28.813030',5,5,5),(66,'Loyer January 2027','2027-01-08','2027-02-07',300000.00,0.00,'2027-01-08','attente','','2026-06-08 09:52:28.852200',5,5,5),(67,'Loyer February 2027','2027-02-08','2027-03-07',300000.00,0.00,'2027-02-08','attente','','2026-06-08 09:52:28.879032',5,5,5),(68,'Loyer March 2027','2027-03-08','2027-04-07',300000.00,0.00,'2027-03-08','attente','','2026-06-08 09:52:28.901023',5,5,5),(69,'Loyer April 2027','2027-04-08','2027-05-07',300000.00,0.00,'2027-04-08','attente','','2026-06-08 09:52:28.956401',5,5,5),(70,'Loyer May 2027','2027-05-08','2027-06-07',300000.00,0.00,'2027-05-08','paye','','2026-06-08 09:52:28.978118',5,5,5);
/*!40000 ALTER TABLE `loyers_loyer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loyers_paiement`
--

DROP TABLE IF EXISTS `loyers_paiement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loyers_paiement` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `montant` decimal(12,2) NOT NULL,
  `date_paiement` date NOT NULL,
  `mode_paiement` varchar(20) NOT NULL,
  `reference` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `loyer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `loyers_paiement_created_by_id_5fcdb5fc_fk_auth_app_user_id` (`created_by_id`),
  KEY `loyers_paiement_loyer_id_60c19813_fk_loyers_loyer_id` (`loyer_id`),
  CONSTRAINT `loyers_paiement_created_by_id_5fcdb5fc_fk_auth_app_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `auth_app_user` (`id`),
  CONSTRAINT `loyers_paiement_loyer_id_60c19813_fk_loyers_loyer_id` FOREIGN KEY (`loyer_id`) REFERENCES `loyers_loyer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loyers_paiement`
--

LOCK TABLES `loyers_paiement` WRITE;
/*!40000 ALTER TABLE `loyers_paiement` DISABLE KEYS */;
INSERT INTO `loyers_paiement` VALUES (88,300000.00,'2026-06-02','virement','','2026-06-02 12:41:09.835658',1,30),(89,325000.00,'2026-06-02','virement','','2026-06-02 14:33:07.833991',2,31),(90,325000.00,'2026-06-03','virement','','2026-06-03 10:29:08.678582',1,32),(91,325000.00,'2026-06-03','virement','','2026-06-03 15:19:14.225741',1,33),(92,300000.00,'2026-06-03','virement','','2026-06-03 15:22:51.877351',1,39),(93,325000.00,'2026-06-05','virement','','2026-06-05 15:55:18.299984',1,39),(94,200000.00,'2026-06-08','virement','','2026-06-08 10:54:45.585648',2,70),(95,300000.00,'2026-06-09','especes','','2026-06-09 09:28:51.173183',1,70);
/*!40000 ALTER TABLE `loyers_paiement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications_notification`
--

DROP TABLE IF EXISTS `notifications_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications_notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `titre` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `type_notif` varchar(20) NOT NULL,
  `lu` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `destinataire_locataire_id` bigint(20) DEFAULT NULL,
  `destinataire_proprietaire_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifi_destinataire_locatai_fce6358c_fk_locataire` (`destinataire_locataire_id`),
  KEY `notifications_notifi_destinataire_proprie_ae10a113_fk_proprieta` (`destinataire_proprietaire_id`),
  CONSTRAINT `notifications_notifi_destinataire_locatai_fce6358c_fk_locataire` FOREIGN KEY (`destinataire_locataire_id`) REFERENCES `locataires_locataire` (`id`),
  CONSTRAINT `notifications_notifi_destinataire_proprie_ae10a113_fk_proprieta` FOREIGN KEY (`destinataire_proprietaire_id`) REFERENCES `proprietaires_proprietaire` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_notification`
--

LOCK TABLES `notifications_notification` WRITE;
/*!40000 ALTER TABLE `notifications_notification` DISABLE KEYS */;
INSERT INTO `notifications_notification` VALUES (1,'Bordereau validé','Votre bordereau de paiement a été validé ✅.','bordereau',1,'2026-05-10 14:10:21.033875',1,NULL),(22,'Bordereau validé','Votre bordereau de paiement a été validé ✅.','bordereau',1,'2026-05-11 08:54:57.914173',1,NULL),(23,'Bordereau validé','Votre bordereau de paiement a été validé ✅.','bordereau',1,'2026-05-26 08:08:32.273864',1,NULL);
/*!40000 ALTER TABLE `notifications_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proprietaires_proprietaire`
--

DROP TABLE IF EXISTS `proprietaires_proprietaire`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proprietaires_proprietaire` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `telephone` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `adresse_province` varchar(100) NOT NULL,
  `adresse_commune` varchar(100) NOT NULL,
  `adresse_quartier` varchar(100) NOT NULL,
  `informations_complementaires` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `mot_de_passe_temp` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proprietaires_proprietaire`
--

LOCK TABLES `proprietaires_proprietaire` WRITE;
/*!40000 ALTER TABLE `proprietaires_proprietaire` DISABLE KEYS */;
INSERT INTO `proprietaires_proprietaire` VALUES (1,'NKURUNZIZA Jean Pierre','+257 79 001 001','jean@email.com','Bujumbura','Mukaza','Rohero','','2026-05-09 19:06:27.534397',''),(2,'Ruberinyange Johnatta','2576800232','johnatta@gmail.com','Bujumbura','Mukaza','Rohero','','2026-05-12 15:28:06.126421',''),(4,'Ngenzebuhoro Hilaire','2573022255','hilaire@gmail.com','Bujumbura','Mukaza','Rohero','','2026-06-03 10:21:24.198106',''),(5,'Gahungu Eloi','','','Gitega','Gitega','','','2026-06-05 10:38:57.255190','');
/*!40000 ALTER TABLE `proprietaires_proprietaire` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'adexpert_recouvrement_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-09 12:56:31
